//Mohamed Mesbahi                  CSC5                   Chapter 3, P. 144, #13
//
/*******************************************************************************
 *
 * Convert US dollars to YEN and EUROS
 * _____________________________________________________________________________
 * This program will convert U.S. dollar amounts to Japanese yen and to euros,
 * storing the conversion factors in the constants YEN_PER_DOLLAR and 
 * EUROS_PER_DOLLAR . To get the most up-to-date exchange rates, search the 
 * Internet using the term “currency exchange rate”.
 * _____________________________________________________________________________
 * CONSTANTS
 * YEN_PER_DOLLAR  : Exchange rate of USD and YEN
 * EURO_PER_DOLLAR : Exchange rate of USD and EURO
 * 
 * INPUT
 * 
 * amountUsd    :   Amount in US Dollars
 * 
 * OUTPUT
 * amountYen    :   Amount in Japanese YEN
 * amountEuro   :   Amount in EURO
 ******************************************************************************/

//Preprocessor Directives (System Libraries)
#include<iostream>
#include<iomanip> 
using namespace std;             //Namespace std of system libraries

//Main Function
int main()
{
	//Local Constants 
        const float YEN_PER_DOLLAR   = 110.85,  //Exchange rate of USD and YEN
		    EURO_PER_DOLLAR = .84;    //Exchange rate of USD and EUROS

        float amountUsd,        //INPUT - Amount in US Dollars
	      amountYen,        //OUTPUT - Amount in Japanese YEN
	      amountEuro;      //OUTPUT - Amount in EURO

	//INPUT - Ask the user to enter the amount he wish to convert in USD
	cout << "Enter the Amount you wish to convert in US Dollars: ";
	cin  >> amountUsd;   //INPUT - Read Input Data

	//PROCESS - Convert U.S. dollars to YEN and EURO 
	amountYen = amountUsd * YEN_PER_DOLLAR;
	amountEuro = amountUsd * EURO_PER_DOLLAR;

	//OUTPUT - Display the converted amounts in YEN and EURO
	cout << fixed << showpoint << setprecision(2);
        cout << "Based on the most recent exchange rates" << endl;
        cout << "$" << amountUsd << " U.S. dollar is equivalent to ";
	cout << amountYen << " YEN and " << amountEuro << " EUR." << endl;
	return 0;
}