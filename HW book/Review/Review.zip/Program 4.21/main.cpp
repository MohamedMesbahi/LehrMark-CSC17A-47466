//Mohamed Mesbahi                  CSC5                   Chapter 4, P. 225, #21
//
/*******************************************************************************
 *
 * GEOMETRY CALCULATOR
 * _____________________________________________________________________________
 * This program displays the following menu:
 *   Geometry Calculator
 *    1. Calculate the Area of a Circle
 *    2. Calculate the Area of a Rectangle  
 *    3. Calculate the Area of a Triangle
 *    4. Quit
 * Enter your choice (1-4):
 * 
 * If the user enters 1, the program should ask for the radius of the circle 
 * and then display its area using the following formula:
 * area = *r2
 *  If the user enters 2, the program should ask for the length and width of
 * the rectangle and then display the rectangle's area.
 * Use the following formula: area = length * width
 * If the user enters 3 the program should ask for the length of the triangle's
 * base and its height, and then display its area. 
 * Use the following formula: area = base * height * .5
 * If the user enters 4, the program should end.
 * ___________________________________________________________________________
 * CONSTANTS
 *  PI = 3.14159 
 * 
 * INPUT
 *  choice      : Chosen operation by the user
 *  radius      : Radius of the circle
 *  length      : Length of the rectangle          
 *  width       : Width of the  rectangle
 *  height      : Height of the triangle
 *  base        : Base of the second triangle
 * 
 * OUTPUT
 *  cirleArea       : Area of the circle
 *  rectangleArea   : Area of the rectangle
 *  triangleArea    : Area of the triangle
 ******************************************************************************/

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

int main (){

   const double PI = 3.14159;         

   int choice;
   double cirleArea;
   double radius;       
   float length;
   float width;
   float base;                  
   float height;    
   float rectangleArea;
   float triangleArea;

   // Prompt the Menu to the user
   cout << "Geometry Calculator" << endl << endl;
   cout << right;
   cout << setw(36) << "1. Calculate the Area of a Circle" << endl;
   cout << setw(39) << "2. Calculate the Area of a Rectangle" << endl;
   cout << setw(38) << "3. Calculate the Area of a Triangle" << endl;
   cout << setw(10) << "4. Quit" << endl << endl;
   cout << setw(30) << "Enter your choice (1-4): " << endl;

   //INPUT - Choice of the user
   cin >> choice;

   //Process & OUTPUT - Switch statement execution
   switch(choice){
   case 1: cout << "Please enter the radius of the circle: " << endl;
	   cin >> radius;
	   if (radius < 0)
	cout << "You entered a negative value, "
		 <<	"Please run the program again";
	   else {
       cirleArea = radius * radius * PI;
       cout << setprecision(5) << fixed;
       cout << "The area of the circle is : " << cirleArea << endl;
	   }
       break;
   case 2: cout << "Please enter the length of the rectangle: " << endl;
	   cin >> length;
	   if (length < 0)
		   cout << "You entered a negative value, "
				<<  "Please run the program again";
	   cout << "Please enter the width of the rectangle" << endl;
	   cin >> width;
	   if (width < 0)
		   cout << "You entered a negative value, "
				<<  "Please run the program again";
	   else {
       rectangleArea = length * width;
       cout << setprecision(4) << fixed;
       cout << "The area of the rectangle is : " << rectangleArea << endl;
	   }
       break;
   case 3: cout << "Please enter the length of the triangle's base: " << endl;
       cin >> base;
       if (base < 0)
    	   cout << "You entered a negative value, "
		        <<  "Please run the program again";
       cout << "Please enter the height of the triangle: " << endl;
       cin >> height;
       if (height < 0)
    	   cout << "You entered a negative value, Please run the program again";
       else {
       triangleArea = base * height * .5;
       cout << setprecision(4) << fixed;
       // Output Result
       cout << "The area of the triangle is : " << triangleArea << endl;
       }
       break;
   case 4: return 0;
       break;
   default : cout << "Error. Run the program again\n";
   }

   return 0;
}