//Mohamed Mesbahi                  CSC5                   Chapter 5, P. 295, #11
//
/*******************************************************************************
 *
 * Predict the size of a population
 * _____________________________________________________________________________
 * This program will predict the size of a population of organisms. The program
 * should ask the user for the starting number of organisms, their average 
 * daily population increase (as a percentage), and the number of days they will 
 * multiply. A loop should display the size of the population for each day.
 * Input Validation: Do not accept a number less than 2 for the starting size 
 * of the population.Do not accept a negative number for average daily 
 * population increase. Do not accept a number less than 1 for the number of 
 * days they will multiply.
 * _____________________________________________________________________________
 * 
 * INPUT
 * .
 * days          : the number of days they will multiply
 * sizeOfPop     : The starting number of organisms
 * dailyIncrease : average daily population increase (as a percentage)
 * 
 * OUTPUT
 * Display the size of the population for each day
 ******************************************************************************/

//Preprocessor Directives (System Libraries)
#include <iostream>
#include <iomanip>
using namespace std;

//Main Function
int main()
{
	unsigned int days,	        // The number of days they will multiply
		     sizeOfPop;		// The starting number of organisms.
	float	dailyIncrease;		// The average daily population increase

	// Ask user for the starting number of organisms, their average daily
	// population increase (as a percentage of current population), 
        // and the number of days they will multiply
	cout << "What is the starting number of organisms? ";
	cin  >> sizeOfPop;
	cout << "What is the average daily population increase\n";
	cin  >> dailyIncrease;
	cout << "Enter the number of days of growth: ";
	cin  >> days;

	// Input Validation
	while (sizeOfPop < 2 || dailyIncrease < 0 || days < 1)
	{
		if (sizeOfPop < 2)
		{ // Do not accept a number less than two for the 
		  // starting size of the population.
			cout << "Error!\nStarting size of population "
				 << "must be greater than 2.\n";
			cout << "What is the starting number of organisms? ";
			cin  >> sizeOfPop;
		}
		else if (dailyIncrease < 0)
		{ // Do not accept a negative number for 
                  //average daily population increase.
		     cout << "Error!\nAverage daily population "
				 << "increase must be greater than 0.\n";
		     cout << "What is the average daily population increase? \n"
				 << "(as a percentage of current population)? ";
		     cin  >> dailyIncrease;
		}
		else if (days < 1)
		{ // Do not accept a number less than one for the number of days
		  // they will multiply.
		       cout << "Error!\nNumber of days must be greater than 0.";
		       cout << "Enter the number of days of growth: ";
		       cin  >> days;
		}
	}


	// Calculate and display daily increase
	cout << "\nTable displaying population increase over " 
             << days << " days.\n"
             << "      Day              Size of population\n"
	     <<"--------------------------------------------------\n";


	for (int i = 1; i <= days; i++)
	{
		cout << "      " << setw(2) << i << "                      "
			 << sizeOfPop << endl; 
		sizeOfPop *= (1 + (dailyIncrease / 100));
	}
	return 0;
}