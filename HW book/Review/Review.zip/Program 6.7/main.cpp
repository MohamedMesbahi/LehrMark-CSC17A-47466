//Mohamed Mesbahi                  CSC5                    Chapter 6, P. 368, #7
//
/*******************************************************************************
 *
 * Convert Fahrenheit temperatures to Celsius
 * _____________________________________________________________________________
 * The formula for converting a temperature from Fahrenheit to Celsius is:
 *                             C=5/9(F-32)
 * where F is the Fahrenheit temperature and C is the Celsius temperature. 
 * Write a function named celsius that accepts a Fahrenheit temperature as an 
 * argument. The function should return the temperature, converted to Celsius. 
 * Demonstrate the function by calling it in a loop that displays a table of the 
 * Fahrenheit temperatures 0 through 20 and their Celsius equivalents.
 * _____________________________________________________________________________
 * OUTPUT
 * Display a table of the Fahrenheit temperatures 0 through 20and their Celsius 
 * equivalents
 * _____________________________________________________________________________
 * Function Prototype
 * celsius : This function accepts a Fahrenheit temperature as an argument
 * and returns the temperature converted into Celsius.
 ******************************************************************************/

//Preprocessor Directives (System Libraries)
#include <iostream>
#include <iomanip>
using namespace std;

// Function Prototypes
float celsius(int);

int main()
{
    int temperatureF;
    
	cout << "\nTable of Fahrenheit temperatures 0 - 20\n"
		 << "and their Celsius equivalents.\n\n"
		 << "------------------------------\n"
		 << "  Fahrenheit       Celsius\n"
		 << "------------------------------\n";
    
	for (temperatureF = 0; temperatureF <= 20; temperatureF++)
	{
		cout << "      " << setw(2) << temperatureF;
		cout << "          "
			 << setw(3) << celsius(temperatureF) << endl;
	}
	cout << endl;
	return 0;
}
/*****************************************************************
 *                        celsius                                *
 * This function accepts a Fahrenheit temperature as an argument *
 * and returns the temperature converted into Celsius.           *
 *****************************************************************/
float celsius(int fahrenheit)
{
	
	return (5.0 * (fahrenheit - 32))/9;
}