//Mohamed Mesbahi          CSC5          Chapter 3, P. 148, #22
//
/**************************************************************
 *
 * CREATE A STORY USING A WORD GAME
 * ____________________________________________________________
 * This program plays a word game with the user0 The program
 * should ask the user to enter the following:
 *       His or her name
 *       His or her age
 *       The name of a city
 *       The name of a college
 *       A profession
 *       A type of animal
 *       A pet's name
 * After the user has entered these items, the program should
 * display the following story, inserting the user s input
 * into the appropriate locations:
 * There once was a person named NAME who lived in CITY. At the age of
 * AGE, NAME went to college at COLLEGE. NAME graduated and went to work
 * as a PROFESSION. Then, NAME adopted a(n) ANIMAL named PETNAME. They
 * both lived happily ever after!
 * ____________________________________________________________
 * INPUT
 *   firstName    : The user's first name
 *   age          : The user's age
 *   cityName     : The name of a city
 *   collegeName  : The name of a college
 *   profession   : A profession
 *   animal       : A type of animal
 *   petName      : A pet's name
 *
 **************************************************************/
#include <iostream>

using namespace std;

int main (){

   char firstName[30];        //INPUT - The user's first name
   int age;                   //INPUT - The user's age
   char cityName[30];         //INPUT - The name of a city
   char collegeName[30];      //INPUT - The name of a college
   char profession[30];       //INPUT - A profession
   char animal[30];           //INPUT - A type of animal
   char petName[30];          //INPUT - A pet's name

   // Ask the user for INPUT
   cout << "Please enter your name" << endl;
   cin.get(firstName,30);
   cin.ignore();
   cout << "Please enter your age" << endl;
   cin >> age;
   cin.ignore();
   cout << "Please enter the name of a city" << endl;
   cin.get(cityName,30);
   cin.ignore();
   cout << "Please enter the name of a college" << endl;
   cin.get(collegeName,30);
   cin.ignore();
   cout << "Please enter a profession" << endl;
   cin.get(profession,30);
   cin.ignore();
   cout << "Please enter a type of animal" << endl;
   cin.get(animal,30);
   cin.ignore();
   cout << "Please enter a pet's name" << endl;
   cin.get(petName,30);

   // Output Result
   cout << "There once was a person named " << firstName
        << " who lived in " << cityName
        << ". At the age of " << endl << age
        << ", " << firstName
        << " went to college at " << collegeName
        << ". " << firstName
        << " graduated and went to work "<< endl
		<< "as a(n) " << profession
        << ". Then, " << firstName
        << " adopted a(n) " << animal
        << " named " << petName
        << ". " << endl
		<<"They both lived happily ever after.";

   return 0;
}