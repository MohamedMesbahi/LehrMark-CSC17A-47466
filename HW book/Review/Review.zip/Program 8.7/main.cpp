//Mohamed Mesbahi                  CSC5                    Chapter 8, P. 493, #7
//
/*******************************************************************************
 *
 * Binary Search on Array of Strings
 * _____________________________________________________________________________
 * Modify the binarySearch function presented in this chapter so it searches an 
 * array of strings instead of an array of integers. Test the function with a 
 * driver program. Use Program 8-8 as a skeleton to complete. (The array must 
 * be sorted before the binary search will work.).
 * _____________________________________________________________________________
 * INPUT
 * name : User input which it is going to be searched for
 * 
 * OUTPUT
 * Display if the entered name was found in the string array and in which 
 * position
 * _____________________________________________________________________________
 * Function Prototype
 * binarySearch  : This function performs a binary search on a string array 
 * selectionSort : This function performs an ascending-order selection sort 
 * on a string array. This parameter size holds the number of elements in the 
 * array. 
 * getValue      : This function asks the user a string value and returns it.
 ******************************************************************************/

//Preprocessor Directives (System Libraries)
#include <iostream>
#include <string>
using namespace std;

// Function prototype
int binarySearch(string[], int, string);
void selectionSort(string[], int);
string getValue();

//Main Function
int main()
{
	const int SIZE = 20;

	string name[SIZE] =
	{"Collins, Bill", "Smith, Bart", "Michalski, Joe", "Griffin, Jim",
	"Sanchez, Manny", "Rubin, Sarah", "Taylor, Tyrone", "Johnson, Jill",
	"Allison, Jeff", "Moreno, Juan", "Wolfe, Bill", "Whitman, Jean",
	"Moretti, Bella", "Wu, Hong", "Patel, Renee", "Harrison, Rose",
	"Smith, Cathy", "Conroy, Pat", "Kelly, Sean", "Holland, Beth"};

	string value;     //Holds the user input
	int result;       //Holds the result of binary search (subscript or -1)

        //Call Functions
	selectionSort(name, SIZE);
	value = getValue();
	result = binarySearch(name, SIZE, value);

	if (result == -1)
		cout << "Name is not in the list.\n";
	else
		cout << name[result] << " was found in subscript #" 
                     << result << ".\n"; 

	return 0;
}
/*******************************************************************************
 *                                selectionSort                                *
 * This function performs an ascending-order selection sort on a string array. *
 * This parameter size holds the number of elements in the array.              *
 ******************************************************************************/
void selectionSort(string array[], int size)
{
	int startScan, minIndex;
	string minValue;

	for (startScan = 0; startScan < (size - 1); startScan++)
	{
		minIndex = startScan;
		minValue = array[startScan];
		for (int index = 0; index < size; index++)
		{
			minValue = array[index];
			minIndex = index;
		}
		array[minIndex] = array[startScan];
		array[startScan] = minValue;
	}
}
/*******************************************************************************
 *                                    getValue                                 *
 * This function asks the user a string value and returns it.                  *
 *******************************************************************************/
string getValue()
{
	string name;
	cout << "Enter the name you would like to search for: ";
	getline(cin, name);
	return name;
}

/*******************************************************************************
 *                               binarySearch                                  *
 * This function performs a binary search on a string array 
 ******************************************************************************/
int binarySearch(string array[], int size, string value)
{
	int first = 0,				// First array element
	last = size - 1,		        // Last array element
	middle,				        // Midpoint of search
	position = -1;			        // Position of search value
	bool found = false;			// Flag

	while (!found && first <= last)
	{
		middle = (first + last) / 2; 	// Calculate midpoint
		if (array[middle] == value)	// If value is found at mid
		{
			found = true;
			position = middle;
		}
		else if (array[middle] > value) // If value is in lower half
			last = middle - 1;
		else
			first = middle + 1;	// If value is in upper half
	}
	return position;	
}