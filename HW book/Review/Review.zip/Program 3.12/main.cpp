//Mohamed Mesbahi                  CSC5                   Chapter 3, P. 144, #12
//
/*******************************************************************************
 *
 * Convert Temperature from Celsius to Fahrenheit
 * _____________________________________________________________________________
 * This program converts Celsius temperatures to Fahrenheit temperatures. 
 * 
 * Computations are based on the Formula: 
 *               F=9/5C+32
 * with F temperature in Fahrenheit, and C the temperature in Celsius
 * _____________________________________________________________________________
 * INPUT
 * 
 * temperatureC  : Temperature entered by the user in Celsius
 * 
 * OUTPUT
 *  temperatureF : Temperature in Fahrenheit
 ******************************************************************************/

#include <iostream>              //Preprocessor Directive (System Library)
using namespace std;             //Namespace std of system libraries

//Main Function
int main()
{
        //Variables declaration
	float temperatureC,   //INPUT - Temperature in Celsius
              temperatureF;   //OUTPUT- Temperature in Fahrenheit

	cout << "This program converts the temperature "
                "from Celsius to Fahrenheit" << endl;
        
        //INPUT - Ask the user to enter the temperature value in Celsius 
	cout << "Enter the temperature in Celsius: ";
	cin  >> temperatureC;   //INPUT - Read the entered data

	//PROCESS - Compute the temperature in Fahrenheit
        temperatureF = (9/5 * temperatureC) + 32;
        
        //OUTPUT - Display the temperature in Fahrenheit
	cout << "The temperature in Fahrenheit is: " << temperatureF << "F";
	return 0;
}