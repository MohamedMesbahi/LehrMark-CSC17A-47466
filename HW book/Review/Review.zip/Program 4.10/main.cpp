//Mohamed Mesbahi                  CSC5                   Chapter 4, P. 221, #11
//
/*******************************************************************************
 *
 * Calculate Number of days in a Month in a particular year
 * _____________________________________________________________________________
 * This program asks the user to enter the month (letting the user enter an 
 * integer in the range of 1 through 12) and the year. The program should then 
 * display the number of days in that month. Use the following criteria to 
 * identify leap years:
 *  1. Determine whether the year is divisible by 100. If it is, then it is a 
 *     leap year if and only if it is divisible by 400. For example, 2000 is 
 *     a leap year but 2100 is not.
 *  2. If the year is not divisible by 100, then it is a leap year if and if 
 *     only it is divisible by 4. For example, 2008 is a leap year but 
 *     2009 is not.
 * _____________________________________________________________________________
 * CONSTANTS
 * NUMBER_OF_MONTHS  : Days Array size
 * 
 * INPUT
 * 
 * monthIn    :   Holds user input for month
 * yearIn     :   Holds user input for year
 * 
 * OUTPUT
 * days       :   Number of days in a month
 * _____________________________________________________________________________
 * Functions
 * isLeapYr  : This function accepts 3 integer arguments. It calculates 
 * and stores the number of days in February for leap years.
 ******************************************************************************/

//Preprocessor Directives (System Libraries)
#include <iostream>
#include <string>
#include <ctime>
using namespace std;

// Function Prototypes
void isLeapYr(int *, int, int);

//Main Function
int main()
{
       //Days Array size
        const int NUMBER_OF_MONTHS = 12; // Number of months
        
	// Array of number of days in each month.
	int days[NUMBER_OF_MONTHS] = {31, 28, 31, 30, 31, 30, 
                                      31, 31, 30, 31, 30, 31};
        
        int *pdays = days;		// Pointer to integer
	unsigned int monthInp,	        // Holds user input for month
		     yearIn;		// Holds user input for year

	//INPUT - Ask the user to enter the month and year.
	cout << "Enter the month and year: ";
	cin  >> monthInp >> yearIn;  //INPUT - Read Data

		//PROCESS - Call isLeapYr function.
		isLeapYr(pdays, monthInp, yearIn);	
				
		//OUTPUT - Display the number of days in a specified month.
		cout << *pdays << " days.\n";

	return 0;
}

//******************************************************************************
//                                 isLeapYr                                    *
// This function calculates and stores the number of days in february for      *
// leap years.                                                                 *
//******************************************************************************
void isLeapYr(int *pDays, int month, int year)
{
	if (month == 2)
	{
		if ((year % 100 == 0 && year % 400 == 0) || 
                    (year % 100 != 0 && year % 4 == 0))
		{
			*pDays = 29;
		}
		else
			*pDays = 28;

	}
}