/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   donList.h
 * Author: Admin
 *
 * Created on September 27, 2017, 3:05 AM
 */

#ifndef DONLIST_H
#define DONLIST_H

class DonationList
{
private:
	int numDonations;
	double *donations;
	double **arrPtr;
	void selectSort();
public:
	DonationList();
	~DonationList();
	void show();
	void showSorted();
};

#endif /* DONLIST_H */

