//Mohamed Mesbahi                      CSC5                 Chapter 9, P.538, #4
//
/*******************************************************************************
 * SORT SCORES AND DISPLAY AVERAGES #2
 * _____________________________________________________________________________
 * 
 * Modify the program of Programming Challenge 2 to allow the user to enter 
 * name-score pairs. For each student taking a test, the user types the 
 * student s name followed by the student s integer test score. Modify the 
 * sorting function so it takes an array holding the student names and an 
 * array holding the student test scores. When the sorted list of scores is 
 * displayed, each student s name should be displayed along with his or her 
 * score.In stepping through the arrays, use pointers rather than array 
 * subscripts.
 * 
 * ****************************************************************************/
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

struct Data
{
	string name;
	float grade;
};

// Function prototypes
void getData(Data *, int);
void selectionSort(Data *, int);
float getAverage(Data *, int);
void displayData(Data *, int, float);

int main()
{
	Data *test;	        // To dynamically allocate an array
	float average;		// To hold the average of the scores
	int testScores;		// To hold number of scores


	// Get number of scores
	cout << "How many scores do you have to average? ";
	cin  >> testScores;

	// Dynamically allocate an array larger enough
	// to hold the user-defined number of scores
	test = new Data[testScores];	// Allocate memory


	getData(test, testScores);

	selectionSort(test, testScores);

	average = getAverage(test, testScores);

	displayData(test, testScores, average);

	delete [] test;
	test = 0;

	return 0;
}

//*****************************************************************************
//                                 getData                                    *
// This function asks user to input test scores that are stored in an array.  *
// The parameter Scores holds the number of test score to be input.           *
//***************************************************************************** 
void getData(Data *Test, int Scores)
{
	cout << "Enter the names and scores for each student.\n";
	for (int i = 0; i < Scores; i++)
	{
		cout << "Student #" << (i + 1) << endl;
		cout << "   Name: ";
		cin.ignore();
		getline(cin, (Test + i)->name);
		do
		{
			cout << "   Score :"; 
			cin  >> (Test + i)->grade;

			if ((Test + i)->grade < 0)
			{
				cout << "Scores must be greater than 0.\n"
					 << "Re-enter ";
			}
			cout << endl;
		} while ((Test + i)->grade < 0);
	}
}
//*****************************************************************************
//                              selectionSort                                 * 
// This function performs an ascending-order selection sort on the Test array *
// The parameter Scores holds the number of scores in the array.               *
//*****************************************************************************
void selectionSort(Data *Test, int Scores)
{
	int startscan, minIndex;
	Data *minValue;

	for (startscan = 0; startscan < (Scores - 1); startscan++)
	{
		minIndex = startscan;
		*minValue = Test[startscan];
		for (int i = startscan + 1; i < Scores; i++)
		{
			if ((Test + i)->grade < minValue->grade)
			{
				*minValue = Test[i];
				minIndex = i;
			}

		}
		Test[minIndex] = Test[startscan];
		Test[startscan] = * minValue;
	}
} 
//***************************************************************************** 
//                               getAverage                                   *
// This function calculates the average of the scores stored in an array.     *
// The parameter Scores holds the number of scores to average.                * 
//*****************************************************************************
float getAverage(Data *Test, int Scores)
{
	float Total;

	for (int i = 0; i < Scores; i++)
	{
		Total += (Test + i)->grade;
	}

	return Total / Scores;
} 
//*****************************************************************************
//                              displayData                                   *
// This function displays the data in the array of Data structures. The       *
// The parameter Scores holds the number of Data structures and the parameter *
// Avg holds the average of the Grades in the array.                          *
//*****************************************************************************
void displayData(Data *Test, int Scores, float Avg) 
{
	cout << "    Test scores\n";
	cout << "Number of scores: " << Scores << endl;
	cout << "Scores in ascending-order:\n";
	for (int i = 0; i < Scores; i++)
	{
		cout << (Test + i)->name << ": " << (Test + i)->grade << endl;
	}
	cout << fixed << showpoint << setprecision(2);
	cout << "Average of scores: " << Avg << endl; 
}