//Mohamed Mesbahi                      CSC5                 Chapter 9, P.538, #8
//
/*******************************************************************************
 * MODE FUNCTION
 * _____________________________________________________________________________
 * 
 * In statistics, the mode of a set of values is the value that occurs most 
 * often or with the greatest frequency. Write a function that accepts as 
 * arguments the following:
 * A) An array of integers
 * B) An integer that indicates the number of elements in the array
 * The function should determine the mode of the array. That is, it should 
 * determine which value in the array occurs most often. The mode is the value 
 * the function should return. If the array has no mode (none of the values 
 * occur more than once), the function should return -1. 
 * (Assume the array will always contain nonnegative values.)Demonstrate your 
 * pointer prowess by using pointer notation instead of array notation in this 
 * function.
 * 
 * ****************************************************************************/

#include <iostream>   
#include <cstdlib>    
#include <ctime>      

using namespace std; 

// Function prototypes
void markSort(int *, int);
int *mode(int *, int, int &, int &);

using namespace std;

int main(int argc, char** argv) {
    
    //Variables Declaration
    int arraySize;
    int nbrElem;
    int modeFreq;
    int maxVal;
    
    //Pointers Declaration
    int *modeFnd;
    int *modeArr;
    
    //Set the random number generator seed
    srand(static_cast<unsigned int>(time(0)));
    
    //INPUT - Ask the user to enter the array size and its max value
    cout << "Please enter the size of the array: ";
    cin >> arraySize;
    cout << "Please enter its Maximum value: ";
    cin >> maxVal;
    
    //Allocate the modeFnd array
    modeFnd = new int[arraySize];
    
    //Fill the array with random numbers
    for (int index = 0; index < arraySize; index++) 
        *(modeFnd+index) = rand() % maxVal + 1;
    
    //Sort the random numbers in ascending order
    markSort(modeFnd, arraySize);
    
    //Find the Mode
    modeArr = mode(modeFnd, arraySize, modeFreq, nbrElem);
    
    //OUTPUT - Display the number of modes, their frequency and their values
    cout << "\nNumber of modes: " << nbrElem << endl;
    cout << "Mode Frequency: " << modeFreq << endl;
    cout << "Modes: " << endl;
    
    for (int index = 0; index < nbrElem; index++)
         cout << *(modeArr + index) << endl;
    if (*modeArr == -1)
        cout <<"There is no mode in this combination of numbers" << endl;
    
    //Delete the arrays and free the memory
    delete [] modeFnd;
    delete [] modeArr;
    
    return 0;
}

void markSort(int *arr, int size) {
    for (int i = 0; i < size; i++) {
        for (int j = i + 1; j < size; j++) {
            if (*(arr + i) > *(arr + j)) {
                *(arr + i) = *(arr + i) ^ *(arr + j);
                *(arr + j) = *(arr + i) ^ *(arr + j);
                *(arr + i) = *(arr + i) ^ *(arr + j);
            }
        }
    }
}

int *mode(int *arr, int size, int &frequency, int &elemCount)
{
    frequency = 0;
    elemCount = 1;
    int *modeFnl;
    int freqCount = 1;

   for (int index = 1; index < size; index++) {
        if (arr[index] == arr[index - 1]) {
            freqCount++;
            if (freqCount == frequency)  
                elemCount++;
            if (freqCount > frequency) {
                frequency = freqCount;
                elemCount = 1;
            }
        }else 
            freqCount = 1;
}
    modeFnl = new int[elemCount];
    
    *modeFnl = -1;
    
    int count = 0;
    freqCount = 1;
    
    for (int index = 1; index < size; index++) {
        if (arr[index] == arr[index - 1]) {
            freqCount++;
            if (freqCount == frequency) {
                *(modeFnl + count) = *(arr + index); 
                count++;
            }
        }else 
             freqCount = 1;
    }
    
    return modeFnl;
}