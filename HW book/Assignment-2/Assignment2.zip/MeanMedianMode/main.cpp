/*   
   Author: MOHAMED MESBAHI
   Purpose: Mode function
 */

#include <iostream>   
#include <cstdlib>    
#include <ctime>      

using namespace std; 

// Function prototypes
void markSort(int *, int);
int *mode(int *, int, int &, int &);
float getMedian(int *, int);
float getMean(int* , int );

using namespace std;

int main(int argc, char** argv) {
    
    //Variables Declaration
    int arraySize;
    int nbrElem;
    int modeFreq;
    int maxVal;
    float median;
    float mean;
    
    //Pointers Declaration
    int *modeFnd;
    int *modeArr;
    
    //Set the random number generator seed
    srand(static_cast<unsigned int>(time(0)));
    
    //INPUT - Ask the user to enter the array size and its max value
    cout << "Please enter the size of the array: ";
    cin >> arraySize;
    cout << "Please enter its Maximum value: ";
    cin >> maxVal;
    
    //Allocate the modeFnd array
    modeFnd = new int[arraySize];
    
    //Fill the array with random numbers
    for (int index = 0; index < arraySize; index++) 
        *(modeFnd+index) = rand() % maxVal + 1;
    
    //Sort the random numbers in ascending order
    markSort(modeFnd, arraySize);
    
    //Find the mean
    mean = getMean(modeFnd, arraySize);
    
    //Find the Median
    median = getMedian(modeFnd, arraySize);
    
    //Find the Mode
    modeArr = mode(modeFnd, arraySize, modeFreq, nbrElem);
    
    //OUTPUT - Display The mean and median
    cout << "The mean is: " << mean << endl;
    cout << "The median value is: " << median << endl;
            
    //OUTPUT - Display the number of modes, their frequency and their values
    cout << "\nNumber of modes: " << nbrElem << endl;
    cout << "Mode Frequency: " << modeFreq << endl;
    cout << "Modes: " << endl;
    
    for (int index = 0; index < nbrElem; index++)
         cout << *(modeArr + index) << endl;
    
    //Delete the arrays and free the memory
    delete [] modeFnd;
    delete [] modeArr;
    
    return 0;
}

void markSort(int *arr, int size) {
    for (int i = 0; i < size; i++) {
        for (int j = i + 1; j < size; j++) {
            if (*(arr + i) > *(arr + j)) {
                *(arr + i) = *(arr + i) ^ *(arr + j);
                *(arr + j) = *(arr + i) ^ *(arr + j);
                *(arr + i) = *(arr + i) ^ *(arr + j);
            }
        }
    }
}

float getMedian(int *array, int size)
{
	int midPoint = (size - 1) / 2;
	float median;

	if (size % 2 == 0)
	{
		median = (*(array + midPoint) + *(array + (midPoint + 1))) / 2;
	}
	else
		median = *(array + midPoint);

	return median;
}

float getMean(int* array, int size){
    
    float sum=0;
    
    for(int index = 0 ; index < size ; index++){
        sum+= *(array + index);
    }
    return sum / size;
}

int *mode(int *arr, int size, int &frequency, int &elemCount)
{
    frequency = 0;
    elemCount = 1;
    int *modeFnl;
    int freqCount = 1;

   for (int index = 1; index < size; index++) {
        if (arr[index] == arr[index - 1]) {
            freqCount++;
            if (freqCount == frequency)  
                elemCount++;
            if (freqCount > frequency) {
                frequency = freqCount;
                elemCount = 1;
            }
        }else 
            freqCount = 1;
}
    modeFnl = new int[elemCount];
    
    *modeFnl = -1;
    
    int count = 0;
    freqCount = 1;
    
    for (int index = 1; index < size; index++) {
        if (arr[index] == arr[index + 1]) {
            freqCount++;
            if (freqCount == frequency) {
                *(modeFnl + count) = *(arr + index); 
                count++;
            }
        }else 
             freqCount = 1;
    }
    
    return modeFnl;
}