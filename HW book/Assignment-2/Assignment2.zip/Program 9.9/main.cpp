//Mohamed Mesbahi                      CSC5                 Chapter 9, P.539, #9
//
/*******************************************************************************
 * DETERMINE MEDIAN VALUE
 * _____________________________________________________________________________
 * 
 * In statistics, when a set of values is sorted in ascending or descending 
 * order, its median is the middle value. If the set contains an even number of
 * values, the median is the mean, or average, of the two middle values. 
 * Write a function that accepts as arguments the following:
 * A) An array of integers
 * B) An integer that indicates the number of elements in the array
 * The function should determine the median of the array. This value should be 
 * returned as a double. (Assume the values in the array are already sorted.)
 * 
 * ****************************************************************************/
#include <iostream>
using namespace std;

// Function prototype
double getMedian(int *, int);

int main()
{
	const int SIZE = 5;
	int List[SIZE] = {1, 4, 6, 12, 17};
	int *pList = List;

	cout << "Median: " << getMedian(pList, SIZE) << endl;

	return 0;
}

double getMedian(int *array, int size)
{
	int mid = (size - 1) / 2;
	double med;

	if (size % 2 == 0)
	{
		med = (*(array + mid) + *(array + (mid + 1))) / 2;
	}
	else
		med = *(array + mid);


	return med;
}