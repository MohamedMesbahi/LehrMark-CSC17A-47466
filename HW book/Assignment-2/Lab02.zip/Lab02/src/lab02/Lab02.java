/*
 * Author : Mohamed Mesbahi
 * CSC 18A
 * Gross Pay Computation
 */
package lab02;

import java.util.Scanner;
import java.io.PrintStream;

public class Lab02 {

    public static void main(String[] args) {
        
        PrintStream o = System.out;
        
        double hrsEmp1;
        double hrsEmp2;
        double hrsEmp3;
        double hrsRate1;
        double hrsRate2;
        double hrsRate3;
        double grossPay1;
        double grossPay2;
        double grossPay3;
        
       Scanner kb = new Scanner(System.in);
       
      o.printf("Please enter the number of hours worked for employee 1 "
              + "and their hourly rate: ");
      hrsEmp1=kb.nextInt();
      hrsRate1=kb.nextInt();
      o.printf("Please enter the number of hours worked for employee 2 "
              + "and their hourly rate: ");
      hrsEmp2=kb.nextInt();
      hrsRate2=kb.nextInt();
      o.printf("Please enter the number of hours worked for employee 3 "
              + "and their hourly rate: ");
      hrsEmp3=kb.nextInt();
      hrsRate3=kb.nextInt();
      
      if (hrsEmp1 <= 40)
      grossPay1 = hrsRate1 * hrsEmp1;
      else
          grossPay1 = (hrsRate1 * 1.5)*(hrsEmp1 - 40) + (hrsRate1 * 40);
      
      if (hrsEmp2 <= 40)
      grossPay2 = hrsRate2 * hrsEmp2;
      else
      grossPay2 = (hrsRate2 * 1.5)*(hrsEmp2 - 40) + (hrsRate2 * 40);
      
      if (hrsEmp3 <= 40)
      grossPay3 = hrsRate3 * hrsEmp3;
      else
      grossPay3 = (hrsRate3 * 1.5)*(hrsEmp3 - 40) + (hrsRate3 * 40);
      
      o.printf("The gross pay for the first employee is: %.3f\n", grossPay1);
      o.printf("The gross pay for the second employee is: %.3f\n", grossPay2);
      o.printf("The gross pay for the third employee is: %.3f", grossPay3);
         
    }
    
}