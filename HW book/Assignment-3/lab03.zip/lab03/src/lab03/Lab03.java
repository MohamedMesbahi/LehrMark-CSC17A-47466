/*
 * Author : Mohamed Mesbahi
 * Lab 03
 */
package lab03;

public class Lab03 {

public static final int MAX_TERM = 200000;

    public static void main(String[] args) {
               
        int denominator = 1;
        double piVlue = 0.0;
        double term = 4.0/denominator;
        int termCounter = 1;
        int piTerm = 0;
        boolean flag = false;
        
        System.out.printf("Term      |      Value of Pi");
        
        while (termCounter <= MAX_TERM)
        {
            if (termCounter % 2 == 0)
                term = -term;
            
                piVlue = piVlue + term;
                
                if(Math.abs( piVlue - 3.141595 ) < 0.000005 && flag == false){
                    piTerm = termCounter;
                    flag = true;
                }
                
                System.out.printf("\n%d         |      %.10f", termCounter, piVlue);
                termCounter++;
                denominator+=2;
                
                term = 4.0/denominator;   
        }
                    System.out.printf("\nBefore getting a value of pi that begins "
                            + "with 3.14159, whe should use: ");
                    System.out.printf("\n%d terms.", piTerm);
    }
        
    }

   
