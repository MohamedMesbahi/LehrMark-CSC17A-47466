//Mohamed Mesbahi                    CSC18A                             Lab #012
//
/*******************************************************************************
* DETERMINE MULTIPLES OF A NUMBER
* ______________________________________________________________________________
* This program reads two integer values and determine an print whether the 
* first is a multiple of the second.
* 
* Computations are based on the formula :
* number1 % number2
* If it is equal to 0 the first is a multiple of the second.
* ******************************************************************************
* INPUT
* 
* number1	: First Integer Value entered by the user 
* number2	: Second Integer Value entered by the user
* 
* OUTPUT
* 
* Display if the first integer is a multiple of the second. 
*******************************************************************************/
package lab012;

//Import scanner object
import java.util.Scanner;

public class Lab012 {
    
/** The entry main method (the program starts here) */
    public static void main(String[] args) {
        
       /** Variables Declaration */
       int number1;    //INPUT - First Integer Value entered by the user
       int number2;    //INPUT - Second Integer Value entered by the user
      
       /**scanner object named kb */
       Scanner read = new Scanner(System.in);
       
      /**INPUT - Ask the user to enter the first integer value */
      System.out.printf("Please enter the value of the 1st integer: ");
      number1=read.nextInt();    /**INPUT - Read Data */
      
      /**INPUT - Ask the user to enter the second integer value */
      System.out.printf("Please enter the value of the 2nd integer: ");
      number2=read.nextInt();    /**INPUT - Read Data */
     
      /**OUTPUT - Display if the first number is a multiple of the second */
      if (number1 % number2 == 0)
        System.out.printf("%d is a multiple of %d!", number1, number2); 
       else
          System.out.printf("%d is not a multiple of %d!", number1, number2);
    }
    
}