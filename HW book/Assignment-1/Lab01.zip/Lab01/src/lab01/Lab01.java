//Mohamed Mesbahi                    CSC18A                              Lab #01
//
/*******************************************************************************
* DETERMINE EVEN & ODD NUMBERS
* ______________________________________________________________________________
* This program reads an integer and determine and print whether it is odd 
* or even.
* 
* Computations are based on the formula :
* number % 2
* If it is equal to 0 the number is even, if not the number is even
* ******************************************************************************
* INPUT
* 
* number	: Integer Value entered by the user 
* 
* OUTPUT
* 
* Display if the entered value is even or odd. 
*******************************************************************************/
package lab01;

//Import scanner object
import java.util.Scanner;

public class Lab01 {
    
/** The entry main method (the program starts here) */
    public static void main(String[] args) {
        
        /** Variable Declaration */
       int number;    //INPUT - User input
      
       /**scanner object named read */
       Scanner read = new Scanner(System.in);
      
      /**INPUT - Ask the user to enter the integer value */
      System.out.printf("Please enter an integer value: ");
      number=read.nextInt();  /**INPUT - Read Data */
     
      /**OUTPUT - Display if number is even or not */
      if (number % 2 == 0) 
        System.out.printf("%d is even!", number); 
       else
          System.out.printf("%d is odd!", number);
    }
    
}
