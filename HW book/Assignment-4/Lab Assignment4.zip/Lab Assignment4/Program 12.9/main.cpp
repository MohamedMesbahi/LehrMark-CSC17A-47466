/*
 * File:   main.cpp (Chapter 12, pg 702, p9)
 * Author: Mohamed Mesbahi
 * Created on Oct 10th, 2017, 01:20 AM
 * Purpose: File encryption filter
*/

#include <iostream>
#include <fstream>
using namespace std;

int main()
{
	string fileName, encrypt;
	char ch;

	// Ask the user to enter the name of the unencrypted file
	cout << "Enter the name of the file to encrypt: ";
	cin  >> fileName;
	cout << "Enter name for encrypted file: ";
	cin  >> encrypt;

	fstream inFile(fileName, ios::in);
	if (!inFile)
	{
		cout << "Error opening file \"" << fileName << "\".\n";
		return 0;
	}

	fstream outFile(encrypt, ios::out);

	while (!inFile.fail())
	{
		inFile.get(ch);
		ch += 10;
		outFile << ch;
	}

	inFile.close();
	outFile.close();
	return 0;
}