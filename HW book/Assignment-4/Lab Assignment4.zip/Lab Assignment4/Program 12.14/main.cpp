/*
 * File:   main.cpp (Chapter 12, pg 703, p14)
 * Author: Mohamed Mesbahi
 * Created on Oct 10th, 2017, 18:00 PM
 * Purpose: Inventory Screen Report
*/

#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
using namespace std;

struct Inven
{
	string Desc,		// Item decpription
		   Date;	// Date added to inventory
	int    Qty;		// Quantity on hand
	float WhsleCost,	// Wholesale cost
		   RetailCost;	// Retail cost
};

int main()
{	
	Inven record;
	float Totwhsle  = 0,	// Accumulates total wholesale value 
		   TotRetail = 0;// Accumulates total Retail value
	int TotQty = 0;		// Accumulates total quantity of all items

	fstream File("inventory.dat", ios::in | ios::binary);
	if (!File)
	{
		cout << "Error open file, aborting program.\n";
		return 0;
	}

	File.read(reinterpret_cast<char *>(&record), sizeof(record));
	while (!File.fail())
	{
		Totwhsle += record.WhsleCost * record.Qty;
		TotRetail += record.RetailCost * record.Qty;
		TotQty += record.Qty;
		File.read(reinterpret_cast<char *>(&record), sizeof(record));
	}
	File.close();
	cout << fixed << showpoint << setprecision(2);
	cout << "Total wholesale value of the inventory:       $"
		 << setw(10) << Totwhsle << endl;
	cout << "Total retail value of the inventory:          $"
		 << setw(10) << TotRetail << endl;
	cout << "Total quantity of all items in the inventory: $"
		 << setw(10) << TotQty << endl;
	return 0;
}