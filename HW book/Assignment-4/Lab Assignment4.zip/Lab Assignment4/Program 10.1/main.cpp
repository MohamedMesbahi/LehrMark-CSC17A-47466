//Mohamed Mesbahi                   CSC17A                 Chapter 10, P.588, #1
//
/*******************************************************************************
* DISPLAY THE LENGTH OF A C-STRING
* ______________________________________________________________________________
* Write a function that returns an integer and accepts a pointer to a C-string 
* as an argument. The function should count the number of characters in the 
* string and return that number. Demonstrate the function in a simple program 
* that asks the user to input a string, passes it to the function, and then 
* displays the function s return value.
* 
* ******************************************************************************
* INPUT
* 
* Input[]	: C-string that contains data entered by the user
* 
* OUTPUT
* 
* Display the length of the C-string.
* 
* ______________________________________________________________________________
* PROTOTYPE
* stringlen   : This function accepts a C-string as an argument and returns 
*               the length of the C-string as a result.
*******************************************************************************/

#include <iostream>
#include <string>
#include <string.h>
using namespace std;

// Function prototype
int stringlen(char *);

int main()
{
	const int Length = 100;
	char Input[Length];

	// Ask the user to input a string.
	cout << "Enter a string: ";
	cin.getline(Input, Length);

	cout << "Length of " << Input << ": " << stringlen(Input) << endl;

	return 0;
}
//******************************************************************************
// stringlen                                                                   *
// This function accepts a C-string as an argument and returns the length of   *
// the C-string as a result.                                                   *
//******************************************************************************
int stringlen(char *Str)
{
	return strlen(Str);
}