//Mohamed Mesbahi                   CSC17A                 Chapter 10, P.588, #3
//
/*******************************************************************************
* DISPLAY THE NUMBER OF WORDS CONTAINED IN A C-STRING
* ______________________________________________________________________________
* Write a function that accepts a pointer to a C-string as an argument and 
* returns the number of words contained in the string. For instance, if the 
* string argument is Four score and seven years ago the function should return 
* the number 6. Demonstrate the function in a program that asks the user to 
* input a string and then passes it to the function. The number of words in the 
* string should be displayed on the screen. Optional Exercise: Write an 
* overloaded version of this function that accepts a string class object as 
* its argument.
* 
* ******************************************************************************
* INPUT
* 
* Input[LENGTH]	: C-string that contains data entered by the user
* 
* OUTPUT
* 
* Display the number of words contained in the C-string.
* 
* ______________________________________________________________________________
* PROTOTYPE
* wordCount  : This function accepts a C-string as an argument and returns 
*              the number of words contained in the string.
*******************************************************************************/

#include <iostream>
#include <string>
#include <cstring>
using namespace std;

int wordCount(char *);

const int LENGTH = 100;

int main()
{
	char Input[LENGTH];

	// Ask the user to input a string
	cout << "Enter a string: ";
	cin.getline(Input, LENGTH);

	cout << "Number of words in \"" << Input << "\": " << wordCount(Input) << endl;

	return 0;
}

//******************************************************************************
// wordCount                                                                   *
// This function accepts a C-string as an argument and returns the number of   *
// words contained in the string.                                              *
//******************************************************************************
int wordCount(char *Str)
{
	int count = 0;

	for (int i = 0; i < strlen(Str); i++)
	{
		if ((Str[0] != '\0' && i == 0) || Str[i] == ' ')
		{
			count++;
		}
	}
	return count;
}