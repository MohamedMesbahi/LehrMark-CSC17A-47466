/*
 * File:   main.cpp (Chapter 12, pg 702, p12)
 * Author: Mohamed Mesbahi
 * Created on Oct 9th, 2017, 11:30 PM
 * Purpose:  Corporate Sales Data Output
*/
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

const int LENGTH = 4;

struct CorpData
{
	static string Division[LENGTH];
	float Qtr[LENGTH];
	float QtrlySales;
};

string CorpData::Division[LENGTH] = {"East", "West", "North", "South"};

int main()
{
 	CorpData Sales;
 	float TotCorpQtr[LENGTH] = {0,0,0,0}; 	// Total corporate sales for each quarter
 	float TotYrDiv, 		        // Total yearly sales for each division
 		   TotYrCorp, 			// Total yearly corporate sales
 		   Highest,
 		   Lowest;

 	TotYrCorp = TotYrDiv = 0;

 	fstream File("salefigures.txt", ios::in | ios::binary);
 	if (!File)
 	{
 		cout << "Error opening file. Program aborting.\n";
 		return 0;
 	}

 	// Display sales figures.
 	cout << fixed << showpoint << setprecision(2);
 	cout << "\nCorporate Sales Data Report\n"
 		 << "---------------------------\n";
 	cout << "\nTotal sales by division:\n";
 	for (int d = 0; d < LENGTH; d++)
 	{
 		File.read(reinterpret_cast<char *>(&Sales), sizeof(Sales));
 		cout << Sales.Division[d] << ":\n";
 		cout << "  Total yearly Sales: $";
 		for (int q = 0; q < LENGTH; q++)
 		{
 			TotYrDiv += Sales.Qtr[q];
 			TotCorpQtr[q] += Sales.Qtr[q];
 		}
 		cout << TotYrDiv << endl;
 		cout << "  Average quarterly sales: $" << TotYrDiv/4 << endl;
 		TotYrCorp += TotYrDiv;
 	}
 	cout << "\nTotal corporate sales for each quarter:\n";
 	for (int i = 0; i < LENGTH; i++)
 	{
 		cout << "Quarter " << (i + 1) << ": $" << TotCorpQtr[i] << endl;
 	}

 	cout << "\nTotal yearly corporate sales: $" << TotYrCorp << endl;

 	Highest = Lowest = TotCorpQtr[0];

 	for (int i = 1; i < LENGTH; i++)
 	{
 		if (TotCorpQtr[i] > Highest)
 			Highest = TotCorpQtr[i];

 		if (TotCorpQtr[i] < Lowest)
 			Lowest = TotCorpQtr[i];
 	}

 	cout << "The highest quarter for the corporation: " << Highest << endl;
 	cout << "The lowest quarter for the corporation: " << Lowest << endl;

 	File.close();
 	return 0;
}