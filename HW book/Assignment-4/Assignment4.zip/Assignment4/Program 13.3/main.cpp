/* 
 * File:   main.cpp (Chapter 13, pg 792, p3)
 * Author: Mohamed Mesbahi
 * Created on Oct 19th, 2017, 06:30 PM
 * Purpose:  Car class
 */

#include <iostream>
#include "Car.h"
using namespace std;

int main()
{
	// Create a Car object
	Car bmw(2016, "BMW i8");

	// Call accelerate function 5 times and display the current speed of the car
	// after each call.
	bmw.accelerate();
	cout << "Current speed of car: " << bmw.getSpeed() << " MPH" << endl;
	bmw.accelerate();
	cout << "Current speed of car: " << bmw.getSpeed() << " MPH" << endl;
	bmw.accelerate();
	cout << "Current speed of car: " << bmw.getSpeed() << " MPH" << endl;
	bmw.accelerate();
	cout << "Current speed of car: " << bmw.getSpeed() << " MPH" << endl;
	bmw.accelerate();
	cout << "Current speed of car: " << bmw.getSpeed() << " MPH" << endl;

	// Call brake function 5 times and display the current speed of the car
	// after each call.
	bmw.brake();
	cout << "Current speed of car: " << bmw.getSpeed() << " MPH" << endl;
	bmw.brake();
	cout << "Current speed of car: " << bmw.getSpeed() << " MPH" << endl;
	bmw.brake();
	cout << "Current speed of car: " << bmw.getSpeed() << " MPH" << endl;
	bmw.brake();
	cout << "Current speed of car: " << bmw.getSpeed() << " MPH" << endl;
	bmw.brake();
	cout << "Current speed of car: " << bmw.getSpeed() << " MPH" << endl;

	return 0;
}