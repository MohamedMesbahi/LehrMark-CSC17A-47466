/* 
 * File:   main.cpp (Chapter 13, pg 794, p7)
 * Author: Mohamed Mesbahi
 * Created on Oct 18th, 2017, 08:10 PM
 * Purpose:  Widget Factory
 */

#include <iostream>
#include "Widgets.h"
using namespace std;

int main()
{
	Widgets Order;
	int Num;

	// Ask user for the number of widgets ordered
	cout << "\n     Widgets time of completion program\n"
		 << "---------------------------------------------------\n";

	do
	{
		cout << "How many widgets have been ordered? ";
		cin  >> Num;

		if (Num < 0)
		{
			cout << "Error! Invalid Order.\n"
				 << "Widgets Ordered must be greater than 0.\n";

		}
		
	} while (Num < 0);

	Order.numOfDays(Num);

	return 0;
}