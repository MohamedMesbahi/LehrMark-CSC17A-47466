
#include "Employee.h"

Employee::Employee() {
    Name = ""; 
    Id = 0; 
    Dep = ""; 
    Pos = "";
}

Employee::Employee(int I, string N, string D, string P) {
    Name = N; 
    Id = I; 
    Dep = D; 
    Pos = P;
}

Employee::Employee(int I, string N) {
    Name = N; 
    Id = I; 
    Dep = ""; 
    Pos = "";
}

int Employee::getId(){
    return Id;
}

string Employee::getName(){
    return Name;
}

string Employee::getDep(){
    return Dep;
}

string Employee::getPos(){
    return Pos;
}

void Employee::setId(int& I){
    Id = I;
}

void Employee::setName(string& N){
    Name = N;
}

void Employee::setDep(string& D){
    Dep = D;
}

void Employee::setPos(string& P){
    Pos = P;
}
