/* 
 * File:   main.cpp (Chapter 13, pg 791, p2)
 * Author: Mohamed Mesbahi
 * Created on Oct 19th, 2017, 09:43 PM
 * Purpose:  Car class
 */

#include <iostream>
#include <iomanip>
#include "Employee.h"
using namespace std;

int main()
{
    Employee Emp1;
    Employee Emp2;
    Employee Emp3;
    
    string Na,
            De,
            Po;
    int Id;
  
    cout << "\n             Employee's Data\n";
    cout <<"-------------------------------------------\n";
    cout << "Please enter the Name, id, department and position"
            " of the employee#1: ";
    
    getline(cin, Na);
    cin >> Id;
    cin.ignore();
    getline(cin, De);
    getline(cin, Po);
    
    Emp1.setId(Id);
    Emp1.setName(Na);
    Emp1.setDep(De);
    Emp1.setPos(Po);
    
    cout << "Please enter the Name, id, department and position"
            " of the employee#2: ";
    getline(cin, Na);
    cin >> Id;
    cin.ignore();
    getline(cin, De);
    getline(cin, Po);
    
    Emp2.setId(Id);
    Emp2.setName(Na);
    Emp2.setDep(De);
    Emp2.setPos(Po);
    
    cout << "Please enter the Name, id, department and position"
            " of the employee#3: ";
    getline(cin, Na);
    cin >> Id;
    cin.ignore();
    getline(cin, De);
    getline(cin, Po);
    
    Emp3.setId(Id);
    Emp3.setName(Na);
    Emp3.setDep(De);
    Emp3.setPos(Po);
    
    cout << "\n               Employee\n"
		 << "                Table\n";
    cout <<"-------------------------------------------\n";

    cout << fixed << showpoint << setprecision(2);
    cout << "Name             : "  << Emp1.getName() << endl;
    cout << "Id Number        : "  << Emp1.getId() << endl;
    cout << "Department       : " << setw(10)
		 << Emp1.getDep() << endl;
    cout << "Position         : " << setw(10)
	 	 << Emp1.getPos() << endl;
    
    cout <<"-------------------------------------------\n";
    
    cout << "Name             : "  << Emp2.getName() << endl;
    cout << "Id Number        : "  << Emp2.getId() << endl;
    cout << "Department       : " << setw(10)
		 << Emp2.getDep() << endl;
    cout << "Position         : " << setw(10)
	 	 << Emp2.getPos() << endl;
    
    cout <<"-------------------------------------------\n";
    
        cout << "Name             : "  << Emp3.getName() << endl;
    cout << "Id Number        : "  << Emp3.getId() << endl;
    cout << "Department       : " << setw(10)
		 << Emp3.getDep() << endl;
    cout << "Position         : " << setw(10)
	 	 << Emp3.getPos() << endl;
    return 0;
}