
#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string>
using namespace std;

class Employee {
    
    private:
        string Name,
                Dep,
                Pos;
        int Id;
        
    public :
        
        //Default Constructor
        Employee();
        
        Employee(int, string, string, string);
        
        Employee(int, string);
        
	int getId();
        
        string getName();
        
        string getDep();
        
        string getPos();
        
        void setId(int&);

	void setName(string&);
		
	void setDep(string&);
        
        void setPos(string&);
                
};

#endif /* EMPLOYEE_H */

