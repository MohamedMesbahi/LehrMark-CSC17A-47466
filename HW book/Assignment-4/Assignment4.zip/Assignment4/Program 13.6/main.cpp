/* 
 * File:   main.cpp (Chapter 13, pg 793, p6)
 * Author: Mohamed Mesbahi
 * Created on Oct 18th, 2017, 08:10 PM
 * Purpose:  Widget Factory
 */

#include <iostream>
#include "Inventory.h"
#include <iomanip>
using namespace std;

int main()
{
	int Item, Quantity;
	float Cost;

	Inventory iphoneX;

	cout << "\n    iPhoneX Cost Of Goods Sold Report wizard!\n"
		 << "----------------------------------------------------\n";
	cout << "Input the inventory information for beginning of the month.\n";
	cout << "Enter the iphoneX Item Number: ";
	cin  >> Item;
	iphoneX.setItemNumber(Item);

	cout << "Enter the quantity of the iphoneX Item# "
		 << iphoneX.getItemNumber() << " on hand: ";
	cin  >> Quantity;
	iphoneX.setQuantity(Quantity);	
	
	cout << "Enter the wholesale per-unit cost of the iphoneX Item# "
		 << iphoneX.getItemNumber() << ": ";
	cin  >> Cost;
	iphoneX.setCost(Cost);

	cout << "Enter the quantity of iPhoneX Item# " << iphoneX.getItemNumber();
	cout << " purchased during the month: ";
	cin  >> Quantity;
	Quantity += iphoneX.getQuantity();
	iphoneX.setQuantity(Quantity);

	cout << "Enter the quantity of iPhoneX Item# " << iphoneX.getItemNumber();
	cout << " on hand at the end of the month: ";
	cin  >> Quantity;
	Quantity = iphoneX.getQuantity() - Quantity;
	iphoneX.setQuantity(Quantity);


	

	cout << "\n               iPhoneX\n"
		 << "        Cost Of Goods Sold Report\n";
	cout <<"-------------------------------------------\n";

	cout << fixed << showpoint << setprecision(2);
	cout << "Item number              : "  << iphoneX.getItemNumber() << endl;
	cout << "Quantity Sold            : "  << iphoneX.getQuantity() << endl;
	cout << "Cost per-unit Sold       : $" << setw(10)
		 << iphoneX.getCost() << endl;
	cout << "Total cost of goods sold : $" << setw(10)
	 	 << iphoneX.getTotalCost() << endl;

	return 0;
}