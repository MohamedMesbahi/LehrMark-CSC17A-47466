/* 
 * File:   main.cpp (Chapter 13, pg 794, p10)
 * Author: Mohamed Mesbahi
 * Created on Oct 18th, 2017, 11:30 AM
 * Purpose:  Population birth and death rates computation
 */

#include <iostream>
#include "pop.h"
using namespace std;

int main()
{
	int Popu, Births, Deaths;

	cout << "\n  Population birth and death rate calculator\n"
		 << "----------------------------------------------\n";
	cout << "Enter the current population: ";
	cin  >> Popu;
	cout << "Enter the annual number of births: ";
	cin  >> Births;
	cout << "Enter the annual number of deaths: ";
	cin  >> Deaths;


	Pop Test(Popu, Births, Deaths);


	cout << "\n\n   Population birth and death rate Report\n"
		 << "----------------------------------------------\n";
	cout << "Birth Rate: " << Test.getBirthRate() << endl;
	cout << "Death Rate: " << Test.getDeathRate() << endl;
}