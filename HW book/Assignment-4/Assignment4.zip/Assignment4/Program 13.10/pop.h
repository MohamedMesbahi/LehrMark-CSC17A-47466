
#ifndef POP_H
#define POP_H

class Pop
{
	private:
		// Member variables
		int CurrPop,		// Current Population
			Births,		// Annual number of births
			Deaths;		// Annual number of deaths
	public:
		// Member function prototypes
		Pop(int, int, int);

		void setPopulation(int);

		void setBirths(int);

		void setDeaths(int);

		float getBirthRate();

		float getDeathRate();
};

#endif /* POP_H */

