/* 
 * File:   main.cpp (Chapter 13, pg 791, p1)
 * Author: Mohamed Mesbahi
 * Created on Oct 20th, 2017, 10:21 AM
 * Purpose:  Date Class
 */

#include <iostream>
#include <string>
#include "Date.h"
using namespace std;

// Function prototype
void timeSettngs(Date &);

int main()
{
	Date Time;
	char Choice;

	cout << "Your time is incorrect.\n"
		 << "Enter time settings (Y/N)? ";
	cin  >> Choice;

	if (Choice == 'y' || Choice == 'Y')
		timeSettngs(Time);

	return 0;
}

void timeSettngs(Date &Obj)
{
	int m, d, y, c;

	cout << "Welcome to time settings!\n"
		 << "Enter the month: ";
	cin  >> m;
	cout << "Enter the day: ";
	cin  >> d;
	cout << "Enter the year: ";
	cin  >> y;

	Obj.setDate(m, d, y);

	cout << "Enter a number from the menu to choose "
	     << "how your time will be displayed.\n"
	     << " 1. 3/15/10\n"
	     << " 2. March 15, 2010\n"
	     << " 3. 15 March 2010\n"
	     << " 4. Exit time settings.\n";
	cin  >> c;

	switch(c)
	{
		case 1 : Obj.IntDate(Obj);
				 break;
		case 2 : Obj.MthDayYr(Obj);
				 break;
		case 3 : Obj.DayMthYr(Obj);
				 break;
		case 4 : cout << "Exiting time settings....";
	}
}